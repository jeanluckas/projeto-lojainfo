package entidades;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class CategoriaTest {

    private Categoria c;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        c = new Categoria();
    }

    @After
    public void tearDown() {
        c = null;
    }

    @Test
    public void testGettersAndSetters() {
        // Arrange
        int idEsperado = 1;
        String nomeEsperado = "Hardware";
        String descEsperado = "Que xinga";

        // Act
        c.setCodCategoria(idEsperado);
        c.setNome(nomeEsperado);
        c.setDescCategoria(descEsperado);
        
        // Assert
        assertEquals(idEsperado, c.getCodCategoria());
        assertEquals(nomeEsperado, c.getNome());
        assertEquals(descEsperado, c.getDescCategoria());
    }
    
    @Test
    public void testToString() {
        // Arrange
        int idEsperado = 1;
        String nomeEsperado = "Hardware";
        String descEsperado = "Que xinga";

        c.setCodCategoria(idEsperado);
        c.setNome(nomeEsperado);
        c.setDescCategoria(descEsperado);
        // Act
        String esperado = "1;Hardware;Que xinga";
        String obtido = c.toString();

        // Assert
        assertEquals(esperado, obtido);
    }

    @Test
    public void testToStringSemId() {
        // Arrange
        String nomeEsperado = "Hardware";
        String descEsperado = "Que xinga";

        c.setNome(nomeEsperado);
        c.setDescCategoria(descEsperado);

        // Act
        String esperado = "0;Hardware;Que xinga";
        String obtido = c.toString();

        // Assert
        assertEquals(esperado, obtido);
    }
}
