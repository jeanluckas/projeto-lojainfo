package entidades;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class ClienteTest {

    private Cliente c;

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
        c = new Cliente();
    }

    @After
    public void tearDown() {
        c = null;
    }

    @Test
    public void testGettersAndSetters() {
        // Arrange
        int idEsperado = 1;
        String nomeEsperado = "João";
        String telefoneEsperado = "51912341234";
        String emailEsperado = "joao@gmail.com";
        String cpfEsperado = "45929770093";
        String enderecoEsperado = "Lajeado";
        String dataNascEsperada = "25/06/2005";

        // Act
        c.setCodCliente(idEsperado);
        c.setNomeCliente(nomeEsperado);
        c.setTelefone(telefoneEsperado);
        c.setEmail(emailEsperado);
        c.setCpf(cpfEsperado);
        c.setEndereco(enderecoEsperado);
        c.setDataNasc(dataNascEsperada);

        // Assert
        assertEquals(idEsperado, c.getCodCliente());
        assertEquals(nomeEsperado, c.getNomeCliente());
        assertEquals(telefoneEsperado, c.getTelefone());
        assertEquals(emailEsperado, c.getEmail());
        assertEquals(cpfEsperado, c.getCpf());
        assertEquals(enderecoEsperado, c.getEndereco());
        assertEquals(dataNascEsperada, c.getDataNasc());

    }

    @Test
    public void testSemCamposNaoObrigatorios() {
        // Arrange
        int idEsperado = 1;
        String nomeEsperado = "João";
        String enderecoEsperado = "Lajeado";
        String dataNascEsperada = "25/06/2005";

        // Act
        c.setCodCliente(idEsperado);
        c.setNomeCliente(nomeEsperado);
        c.setEndereco(enderecoEsperado);
        c.setDataNasc(dataNascEsperada);

        // Assert
        assertEquals(idEsperado, c.getCodCliente());
        assertEquals(nomeEsperado, c.getNomeCliente());
        assertEquals(enderecoEsperado, c.getEndereco());
        assertEquals(dataNascEsperada, c.getDataNasc());
        assertEquals(null, c.getCpf());
        assertEquals(null, c.getEmail());
        assertEquals(null, c.getTelefone());
    }

    @Test
    public void testToString() {
        // Arrange
        int idEsperado = 1;
        String nomeEsperado = "João";
        String telefoneEsperado = "51912341234";
        String emailEsperado = "joao@gmail.com";
        String cpfEsperado = "45929770093";
        String enderecoEsperado = "Lajeado";
        String dataNascEsperada = "25/06/2005";

        c.setCodCliente(idEsperado);
        c.setNomeCliente(nomeEsperado);
        c.setTelefone(telefoneEsperado);
        c.setEmail(emailEsperado);
        c.setCpf(cpfEsperado);
        c.setEndereco(enderecoEsperado);
        c.setDataNasc(dataNascEsperada);

        // Act
        String esperado = "1;João;51912341234;joao@gmail.com;45929770093;Lajeado;25/06/2005";
        String obtido = c.toString();

        // Assert
        assertEquals(esperado, obtido);
    }

    @Test
    public void testToStringSemCpf() {
        // Arrange
        int idEsperado = 1;
        String nomeEsperado = "João";
        String telefoneEsperado = "51912341234";
        String emailEsperado = "joao@gmail.com";
        String enderecoEsperado = "Lajeado";
        String dataNascEsperada = "25/06/2005";

        c.setCodCliente(idEsperado);
        c.setNomeCliente(nomeEsperado);
        c.setTelefone(telefoneEsperado);
        c.setEmail(emailEsperado);
        c.setEndereco(enderecoEsperado);
        c.setDataNasc(dataNascEsperada);

        // Act
        String esperado = "1;João;51912341234;joao@gmail.com;null;Lajeado;25/06/2005";
        String obtido = c.toString();

        // Assert
        assertEquals(esperado, obtido);
    }
}
