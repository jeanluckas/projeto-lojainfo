package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Categoria;
import entidades.Cliente;
import java.sql.SQLException;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class CategoriaDAOTest {

    private static final String SQL_CREATE_TABLE
            = "CREATE TABLE IF NOT EXISTS categoria ( "
            + "codcategoria SERIAL NOT NULL, "
            + "nome VARCHAR(50) NOT NULL, "
            + "desccategoria VARCHAR(50) NOT NULL, "
            + "CONSTRAINT PK_categoria PRIMARY KEY(codcategoria)"
            + ");";

    private static final String SQL_DROP_TABLE = "DROP TABLE IF EXISTS categoria;";

    private CategoriaDAO dao;

    @BeforeClass
    public static void setUpClass() {
        try {
            System.setProperty("db.config", "db-test.properties");
            ConexaoBD.executeUpdate(SQL_CREATE_TABLE);
        } catch (SQLException e) {
            throw new RuntimeException("Erro em @BeforeClass: falha ao criar tabela 'categoria'.\n" + e.getMessage(), e);
        }
    }

    @AfterClass
    public static void tearDownClass() {
        try {
            ConexaoBD.executeUpdate(SQL_DROP_TABLE);
        } catch (SQLException e) {
            throw new RuntimeException("Erro em @AfterClass: falha ao dropar tabela 'categoria'.\n" + e.getMessage(), e);
        }
    }

    @Before
    public void setUp() {
        ConexaoBD.getInstance().shutdown();

        dao = new CategoriaDAO();

        try {
            ConexaoBD.executeUpdate("TRUNCATE TABLE categoria RESTART IDENTITY;");
        } catch (SQLException e) {
            throw new RuntimeException("Erro em @Before: falha ao truncar tabela 'categoria'.\n" + e.getMessage(), e);
        }
    }

    @After
    public void tearDown() {
        ConexaoBD.getInstance().shutdown();
    }

    @Test
    public void testInserirERecuperarCategoria() throws SQLException {
        // 1) Cria objeto e insere no banco
        Categoria c = new Categoria();
        c.setNome("Hardware");
        c.setDescCategoria("Que chuta");
        dao.salvar(c);

        // 2) Recupera todos, deve haver 1
        ArrayList<Categoria> lista = dao.recuperarTodos();
        assertNotNull("Lista não deve ser nula", lista);
        assertEquals("Deve haver exatamente 1 categoria na tabela", 1, lista.size());

        // 3) Recupera por ID e valida os dados
        Categoria recuperado = dao.recuperarUm(1);
        assertNotNull("recuperarUm(id) não deve retornar null", recuperado);
        assertEquals(1, recuperado.getCodCategoria());
        assertEquals(c.getNome(), recuperado.getNome());
        assertEquals(c.getDescCategoria(), recuperado.getDescCategoria());
    }

    @Test
    public void testEditarCategoria() throws SQLException {
        // 1) Insere um registro inicial
        Categoria c = new Categoria();
        c.setNome("Hardware");
        c.setDescCategoria("Que chuta");
        dao.salvar(c);

        // 2) Edita com novos dados
        Categoria modificado = new Categoria();
        modificado.setCodCategoria(1);
        modificado.setNome("Software");
        modificado.setDescCategoria("Que xinga");
        dao.editar(modificado);

        // 3) Recupera e valida os campos atualizados
        Categoria recuperado = dao.recuperarUm(1);
        assertNotNull("Planeta com ID 1 deveria existir após edição", recuperado);
        assertEquals(1, recuperado.getCodCategoria());
        assertEquals("Software", recuperado.getNome());
        assertEquals("Que xinga", recuperado.getDescCategoria());
    }

    @Test
    public void testExcluirCategoria() throws SQLException {
        // 1) Insere um registro
        Categoria c = new Categoria();
        c.setNome("Hardware");
        c.setDescCategoria("Que chuta");
        dao.salvar(c);

        // Confirma que existe antes da exclusão
        Categoria antes = dao.recuperarUm(1);
        assertNotNull("Categoria com ID 1 deveria existir antes da exclusão", antes);

        // 2) Exclui o cliente de ID = 1
        dao.excluir(1);

        // 3) Verifica que recuperarUm(1) retorna null
        Categoria depois = dao.recuperarUm(1);
        assertNull("recuperarUm(1) deve retornar null após exclusão", depois);

        // 4) Verifica que recuperarTodos() retorna lista vazia
        ArrayList<Categoria> todos = dao.recuperarTodos();
        assertNotNull("Lista retornada por recuperarTodos não deve ser null", todos);
        assertTrue("Lista deve estar vazia após exclusão da categoria", todos.isEmpty());
    }

    public void testRecuperarTodosComMultiplosClientes() throws SQLException {
        // 1) Insere 3 clientes
        String[] nomes = {"João", "Maria", "Mateus"};
        for (String nome : nomes) {
            Categoria c = new Categoria();
            c.setNome(nome);
            c.setDescCategoria("Que chuta");
            dao.salvar(c);
        }

        // 2) Recupera todos e valida
        ArrayList<Categoria> lista = dao.recuperarTodos();
        assertNotNull("Lista não deve ser nula", lista);
        assertEquals("Deve haver exatamente 3 categorias na tabela", 3, lista.size());
    }

}
