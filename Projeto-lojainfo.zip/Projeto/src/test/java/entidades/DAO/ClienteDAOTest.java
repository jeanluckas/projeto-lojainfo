package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Cliente;
import java.sql.SQLException;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class ClienteDAOTest {

    private static final String SQL_CREATE_TABLE
            = "CREATE TABLE IF NOT EXISTS cliente ( "
            + "codcliente SERIAL NOT NULL, "
            + "nomecliente VARCHAR(255) NOT NULL, "
            + "telefone CHAR(11) DEFAULT NULL, "
            + "email VARCHAR(100) DEFAULT NULL, "
            + "cpf CHAR(11) DEFAULT NULL, "
            + "endereco VARCHAR(255) NOT NULL, "
            + "datanasc DATE NOT NULL, "
            + "CONSTRAINT PK_cliente PRIMARY KEY(codcliente), "
            + "CONSTRAINT CHK_datanasc CHECK(datanasc <= CURRENT_DATE AND datanasc > '01/01/1900') "
            + ");";

    private static final String SQL_DROP_TABLE = "DROP TABLE IF EXISTS cliente;";

    private ClienteDAO dao;

    @BeforeClass
    public static void setUpClass() {
        try {
            System.setProperty("db.config", "db-test.properties");
            ConexaoBD.executeUpdate(SQL_CREATE_TABLE);
        } catch (SQLException e) {
            throw new RuntimeException("Erro em @BeforeClass: falha ao criar tabela 'cliente'.\n" + e.getMessage(), e);
        }
    }

    @AfterClass
    public static void tearDownClass() {
        try {
            ConexaoBD.executeUpdate(SQL_DROP_TABLE);
        } catch (SQLException e) {
            throw new RuntimeException("Erro em @AfterClass: falha ao dropar tabela 'cliente'.\n" + e.getMessage(), e);
        }
    }

    @Before
    public void setUp() {
        ConexaoBD.getInstance().shutdown();

        dao = new ClienteDAO();

        try {
            ConexaoBD.executeUpdate("TRUNCATE TABLE cliente RESTART IDENTITY;");
        } catch (SQLException e) {
            throw new RuntimeException("Erro em @Before: falha ao truncar tabela 'cliente'.\n" + e.getMessage(), e);
        }
    }

    @After
    public void tearDown() {
        ConexaoBD.getInstance().shutdown();
    }

    @Test
    public void testInserirERecuperarCliente() throws SQLException {
        // 1) Cria objeto e insere no banco
        Cliente c = new Cliente();
        c.setCodCliente(1);
        c.setNomeCliente("João da Silva");
        c.setTelefone("51999998888");
        c.setEmail("joao.silva@email.com");
        c.setCpf("78091638094");
        c.setEndereco("Rua das Flores, 123");
        c.setDataNasc("2005-06-25");
        dao.salvar(c);

        // 2) Recupera todos, deve haver 1
        ArrayList<Cliente> lista = dao.recuperarTodos();
        assertNotNull("Lista não deve ser nula", lista);
        assertEquals("Deve haver exatamente 1 cliente na tabela", 1, lista.size());

        // 3) Recupera por ID e valida os dados
        Cliente recuperado = dao.recuperarUm(1);
        assertNotNull("recuperarUm(id) não deve retornar null", recuperado);
        assertEquals(1, recuperado.getCodCliente());
        assertEquals(c.getNomeCliente(), recuperado.getNomeCliente());
        assertEquals(c.getTelefone(), recuperado.getTelefone());
        assertEquals(c.getEmail(), recuperado.getEmail());
        assertEquals(c.getCpf(), recuperado.getCpf());
        assertEquals(c.getEndereco(), recuperado.getEndereco());
        assertEquals(c.getDataNasc(), recuperado.getDataNasc());
    }

    @Test
    public void testEditarCliente() throws SQLException {
        // 1) Insere um registro inicial
        Cliente c = new Cliente();
        c.setCodCliente(1);
        c.setNomeCliente("João da Silva");
        c.setTelefone("51999998888");
        c.setEmail("joao.silva@email.com");
        c.setCpf("78091638094");
        c.setEndereco("Rua das Flores, 123");
        c.setDataNasc("25/06/2005");
        dao.salvar(c);

        // 2) Edita com novos dados
        Cliente modificado = new Cliente();
        modificado.setCodCliente(1);
        modificado.setNomeCliente("Brunão");
        modificado.setTelefone("51912341234");
        modificado.setEmail("brunao@gmail.com");
        modificado.setCpf("00627235026");
        modificado.setEndereco("Westfália");
        modificado.setDataNasc("11/10/2005");
        dao.editar(modificado);

        // 3) Recupera e valida os campos atualizados
        Cliente recuperado = dao.recuperarUm(1);
        assertNotNull("Cliente com ID 1 deveria existir após edição", recuperado);
        assertEquals(1, recuperado.getCodCliente());
        assertEquals("Brunão", recuperado.getNomeCliente());
        assertEquals("51912341234", recuperado.getTelefone());
        assertEquals("brunao@gmail.com", recuperado.getEmail());
        assertEquals("00627235026", recuperado.getCpf());
        assertEquals("Westfália", recuperado.getEndereco());
        assertEquals("2005-10-11", recuperado.getDataNasc());
    }

    /**
     * Testa a exclusão de um planeta: 1) Insere um planeta 2) Chama
     * dao.excluir(1) 3) Verifica que dao.recuperarUm(1) retorna null 4)
     * Verifica que dao.recuperarTodos() retorna lista vazia
     */
    @Test
    public void testExcluirCliente() throws SQLException {
        // 1) Insere um registro
        Cliente c = new Cliente();
        c.setCodCliente(1);
        c.setNomeCliente("João da Silva");
        c.setTelefone("51999998888");
        c.setEmail("joao.silva@email.com");
        c.setCpf("78091638094");
        c.setEndereco("Rua das Flores, 123");
        c.setDataNasc("25/06/2005");
        dao.salvar(c);

        // Confirma que existe antes da exclusão
        Cliente antes = dao.recuperarUm(1);
        assertNotNull("Cliente com ID 1 deveria existir antes da exclusão", antes);

        // 2) Exclui o cliente de ID = 1
        dao.excluir(1);

        // 3) Verifica que recuperarUm(1) retorna null
        Cliente depois = dao.recuperarUm(1);
        assertNull("recuperarUm(1) deve retornar null após exclusão", depois);

        // 4) Verifica que recuperarTodos() retorna lista vazia
        ArrayList<Cliente> todos = dao.recuperarTodos();
        assertNotNull("Lista retornada por recuperarTodos não deve ser null", todos);
        assertTrue("Lista deve estar vazia após exclusão do cliente", todos.isEmpty());
    }

    /**
     * Testa a inserção de múltiplos planetas e a recuperação de todos: 1)
     * Insere 3 planetas 2) Recupera todos e valida a quantidade
     */
    @Test
    public void testRecuperarTodosComMultiplosClientes() throws SQLException {
        // 1) Insere 3 clientes
        String[] nomes = {"João", "Maria", "Mateus"};
        for (String nome : nomes) {
            Cliente c = new Cliente();
            c.setCodCliente(1);
            c.setNomeCliente("João da Silva");
            c.setTelefone("51999998888");
            c.setEmail("joao.silva@email.com");
            c.setCpf("78091638094");
            c.setEndereco("Rua das Flores, 123");
            c.setDataNasc("2005-06-25");
            dao.salvar(c);
        }

        // 2) Recupera todos e valida
        ArrayList<Cliente> lista = dao.recuperarTodos();
        assertNotNull("Lista não deve ser nula", lista);
        assertEquals("Deve haver exatamente 3 clientes na tabela", 3, lista.size());
    }
    
}
