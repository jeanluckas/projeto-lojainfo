/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.projeto;

import telas.TelaPrincipal;

/**
 *
 * @author jeanl
 */
public class Projeto {

    public static void main(String[] args) {
        TelaPrincipal tmp = new TelaPrincipal();
        tmp.setVisible(true);
    }
}
