/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author jean.roth
 */
public class Venda {
    private int codVenda;
    private String cliente;
    private String produto;
    private int quantidade;
    private String dtVenda;
    private String formaPagamento;

    public int getIdVenda() {
        return codVenda;
    }

    public void setIdVenda(int idVenda) {
        this.codVenda = idVenda;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getDtVenda() {
        return dtVenda;
    }

    public void setDtVenda(String dtvenda) {
        this.dtVenda = dtvenda;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }
    
    @Override
    public String toString() {
        String retorno = cliente + ";" + produto + ";" + quantidade + ";" + dtVenda + ";" + formaPagamento;
        return retorno;
    }
}
