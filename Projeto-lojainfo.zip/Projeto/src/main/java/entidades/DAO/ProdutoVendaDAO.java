/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.ConexaoBD;
import entidades.ProdutoVenda;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jeanl
 */
public class ProdutoVendaDAO {

    private ResultSet resultadoQ = null; // interface que representa o resultado de uma consulta SQL executada em um banco de dados
    private final ProdutoDAO produtoDAO = new ProdutoDAO();
    private final VendaDAO vendaDAO = new VendaDAO();

    public void inserir(ProdutoVenda pv) throws SQLException {
        String sql = ""
                + "INSERT INTO produtovenda (codvenda, codproduto, quantidade) VALUES ("
                + "" + pv.getVenda().getCodVenda() + ","
                + "" + pv.getProduto().getCodProduto() + ","
                + "" + pv.getQuantidade() + ""
                + ")";

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void remover(ProdutoVenda pv) throws SQLException {

        String sql = ""
                + "DELETE FROM produtovenda WHERE codprodutovenda = " + pv.getId();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public ArrayList<ProdutoVenda> recuperarTodos(int idVenda) throws SQLException {
        ArrayList<ProdutoVenda> produtos = new ArrayList();

        String sql = ""
                + "SELECT * FROM produtovenda WHERE codvenda = " + idVenda;

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            ProdutoVenda venda = new ProdutoVenda();

            venda.setId(resultadoQ.getInt("codprodutovenda"));
            venda.setVenda(vendaDAO.recuperarUm(resultadoQ.getInt("codvenda")));
            venda.setProduto(produtoDAO.recuperarUm(resultadoQ.getInt("codproduto")));
            venda.setQuantidade((resultadoQ.getInt("quantidade")));
            produtos.add(venda);
        }

        return produtos;
    }

    public ProdutoVenda recuperar(int id) throws SQLException {
        ProdutoVenda venda = null;
        String sql = ""
                + "SELECT * FROM produtovenda WHERE codprodutovenda = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            venda = new ProdutoVenda();

            venda.setId(resultadoQ.getInt("codprodutovenda"));
            venda.setVenda(vendaDAO.recuperarUm(resultadoQ.getInt("codvenda")));
            venda.setProduto(produtoDAO.recuperarUm(resultadoQ.getInt("codproduto")));
            venda.setQuantidade((resultadoQ.getInt("quantidade")));
        }

        return venda;
    }
}
