/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.ConexaoBD;
import entidades.ProdutoVenda;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jeanl
 */
public class ProdutoVendaDAO {

    private ResultSet resultadoQ = null; // interface que representa o resultado de uma consulta SQL executada em um banco de dados

    public void salvar(ProdutoVenda pv) throws SQLException {
        String sql = ""
                + "INSERT INTO produtovenda (codvenda, codproduto, quantidade) VALUES ("
                + "" + pv.getCodVenda() + ","
                + "" + pv.getCodProduto() + ","
                + "" + pv.getQuantidade() + ""
                + ")";

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public ArrayList<ProdutoVenda> recuperarTodos() throws SQLException {
        ArrayList<ProdutoVenda> produtos = new ArrayList();

        String sql = ""
                + "SELECT * FROM produtovenda ";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            ProdutoVenda pv = new ProdutoVenda();

            pv.setCodProdutoVenda(resultadoQ.getInt("codprodutovenda"));
            pv.setCodVenda(resultadoQ.getInt("codvenda"));
            pv.setCodProduto(resultadoQ.getInt("codproduto"));
            pv.setQuantidade(resultadoQ.getInt("quantidade"));

            produtos.add(pv);
        }

        return produtos;
    }

    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM produtovenda WHERE codprodutovenda = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void editar(ProdutoVenda pv) throws SQLException {
        String sql = ""
                + "UPDATE produtovenda SET "
                + "codvenda = " + pv.getCodVenda() + ","
                + "codproduto = " + pv.getCodProduto() + ","
                + "quantidade = " + pv.getQuantidade() + " "
                + "WHERE codprodutovenda = " + pv.getCodProdutoVenda();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public ProdutoVenda recuperarUm(int id) throws SQLException {

        String sql = ""
                + "SELECT * FROM produtovenda WHERE codprodutovenda = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            ProdutoVenda pv = new ProdutoVenda();

            pv.setCodProdutoVenda(resultadoQ.getInt("codprodutovenda"));
            pv.setCodVenda(resultadoQ.getInt("codvenda"));
            pv.setCodProduto(resultadoQ.getInt("codproduto"));
            pv.setQuantidade(resultadoQ.getInt("quantidade"));

            return pv;
        }

        return null;
    }
}
