/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.FileManager;
import entidades.Categoria;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class CategoriaDAO {

    private final String caminhoArquivo = "categorias.txt";

    public void salvar(Categoria ctg) {
        FileManager.adicionarLinhaNoArquivo(ctg.toString(), caminhoArquivo);
    }

    public ArrayList<Categoria> recuperarTodos() {
        ArrayList<String> linhas = FileManager.lerLinhasDoArquivo(caminhoArquivo);
        ArrayList<Categoria> categorias = new ArrayList();

        for (String linha : linhas) {
            String[] partes = linha.split(";");
            String nome = partes[0];
            String desc = partes[1];

            Categoria ctg = new Categoria();
            ctg.setNome(nome);
            ctg.setDesc(desc);

            categorias.add(ctg);
        }

        return categorias;
    }
}
