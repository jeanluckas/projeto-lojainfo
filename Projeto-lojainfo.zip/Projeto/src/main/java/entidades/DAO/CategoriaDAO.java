/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Categoria;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class CategoriaDAO {

    private ResultSet resultadoQ = null; // interface que representa o resultado de uma consulta SQL executada em um banco de dados
    
    public void salvar(Categoria ctg) throws SQLException {
        String sql = ""
                + "INSERT INTO categoria (nome, desccategoria) VALUES ("
                + "'" + ctg.getNome() + "',"
                + "'" + ctg.getDescCategoria() + "'"
                + ")";

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public ArrayList<Categoria> recuperarTodos() throws SQLException {
        ArrayList<Categoria> categorias = new ArrayList();
        
        String sql = ""
                + "SELECT * FROM categoria ";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Categoria c = new Categoria();

            c.setCodCategoria(resultadoQ.getInt("codcategoria"));
            c.setNome(resultadoQ.getString("nome"));
            c.setDescCategoria(resultadoQ.getString("desccategoria"));

            categorias.add(c);
        }

        return categorias;
    }
    
    public void excluir(int id) throws SQLException {
        String sql = ""
        + "DELETE FROM categoria WHERE codcategoria = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }
}
