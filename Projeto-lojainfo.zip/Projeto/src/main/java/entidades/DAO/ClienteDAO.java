/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.FileManager;
import entidades.Cliente;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ClienteDAO {

    private final String caminhoArquivo = "clientes.txt";

    public void salvar(Cliente c) {
        FileManager.adicionarLinhaNoArquivo(c.toString(), caminhoArquivo);
    }

    public ArrayList<Cliente> recuperarTodos() {
        ArrayList<String> linhas = FileManager.lerLinhasDoArquivo(caminhoArquivo);
        ArrayList<Cliente> clientes = new ArrayList();

        for (String linha : linhas) {
            String[] partes = linha.split(";");
            String nome = partes[0];
            String cpf = partes[1];
            String telefone = partes[2];
            String email = partes[3];
            String endereco = partes[4];
            String dataNasc = partes[5];

            Cliente c = new Cliente();
            c.setNome(nome);
            c.setCpf(cpf);
            c.setTelefone(telefone);
            c.setEmail(email);
            c.setEndereco(endereco);
            c.setDataNasc(dataNasc);

            clientes.add(c);
        }

        return clientes;
    }

}
