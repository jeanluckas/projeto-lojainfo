/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Cliente;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ClienteDAO {

    private ResultSet resultadoQ = null; // interface que representa o resultado de uma consulta SQL executada em um banco de dados
    
    public void salvar(Cliente c) throws SQLException {
        String sql = ""
                + "INSERT INTO cliente (nomecliente, telefone, email, cpf, endereco, datanasc) VALUES ("
                + "'" + c.getNomeCliente() + "',"
                + "'" + c.getTelefone() + "',"
                + "'" + c.getEmail() + "',"
                + "'" + c.getCpf() + "',"
                + "'" + c.getEndereco() + "',"
                + "'" + c.getDataNasc() + "'"
                + ")";

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public ArrayList<Cliente> recuperarTodos() throws SQLException {
        ArrayList<Cliente> clientes = new ArrayList();
        
        String sql = ""
                + "SELECT * FROM cliente";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Cliente c = new Cliente();

            c.setCodCliente(resultadoQ.getInt("codcliente"));
            c.setNomeCliente(resultadoQ.getString("nomecliente"));
            c.setTelefone(resultadoQ.getString("telefone"));
            c.setEmail(resultadoQ.getString("email"));
            c.setCpf(resultadoQ.getString("cpf"));
            c.setEndereco(resultadoQ.getString("endereco"));
            c.setDataNasc(resultadoQ.getString("datanasc"));

            clientes.add(c);
        }

        return clientes;
    }
    
    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM cliente WHERE codcliente = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }
    
    public void editar(Cliente c) throws SQLException {
        String sql = ""
                + "UPDATE cliente SET "
                + "nomecliente = '" + c.getNomeCliente() + "',"
                + "telefone = '" + c.getTelefone() + "',"
                + "email = '" + c.getEmail() + "',"
                + "cpf = '" + c.getCpf() + "',"
                + "endereco = '" + c.getEndereco() + "',"
                + "datanasc = '" + c.getDataNasc() + "'"
                + "WHERE codcliente = " + c.getCodCliente();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public Cliente recuperarUm(int id) throws SQLException {

        String sql = ""
                + "SELECT * FROM cliente WHERE codcliente = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            Cliente c = new Cliente();

            c.setCodCliente(resultadoQ.getInt("codcliente"));
            c.setNomeCliente(resultadoQ.getString("nomecliente"));
            c.setTelefone(resultadoQ.getString("telefone"));
            c.setEmail(resultadoQ.getString("email"));
            c.setCpf(resultadoQ.getString("cpf"));
            c.setEndereco(resultadoQ.getString("endereco"));
            c.setDataNasc(resultadoQ.getString("datanasc"));

            return c;
        }

        return null;
    }

}
