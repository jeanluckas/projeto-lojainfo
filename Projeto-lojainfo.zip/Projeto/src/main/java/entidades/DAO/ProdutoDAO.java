/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.FileManager;
import entidades.Produto;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ProdutoDAO {
    private final String caminhoArquivo = "produtos.txt";

    public void salvar(Produto p) {
        FileManager.adicionarLinhaNoArquivo(p.toString(), caminhoArquivo);
    }

    public ArrayList<Produto> recuperarTodos() {
        ArrayList<String> linhas = FileManager.lerLinhasDoArquivo(caminhoArquivo);
        ArrayList<Produto> produtos = new ArrayList();

        for (String linha : linhas) {
            String[] partes = linha.split(";");
            String nome = partes[0];
            String preco = partes[1];
            String estoque = partes[2];
            String categoria = partes[3];
       
            Produto p = new Produto();
            p.setNome(nome);
            p.setPreco(Double.parseDouble(preco));
            p.setEstoque(Integer.parseInt(estoque));
            p.setIdCategoria(Integer.parseInt(categoria));
            
            produtos.add(p);
        }

        return produtos;
    }

}
