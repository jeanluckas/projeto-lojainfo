/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Produto;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ProdutoDAO {

    private ResultSet resultadoQ = null; // interface que representa o resultado de uma consulta SQL executada em um banco de dados

    public void salvar(Produto p) throws SQLException {
        String sql = ""
                + "INSERT INTO produto (nomeproduto, preco, estoque, codcategoria) VALUES ("
                + "'" + p.getNomeProduto() + "',"
                + p.getPreco() + ","
                + p.getEstoque() + ","
                + p.getCodCategoria() + ""
                + ")";

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public ArrayList<Produto> recuperarTodos() throws SQLException {
        ArrayList<Produto> produtos = new ArrayList();

        String sql = ""
                + "SELECT * FROM produto";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Produto p = new Produto();

            p.setCodProduto(resultadoQ.getInt("codproduto"));
            p.setNomeProduto(resultadoQ.getString("nomeproduto"));
            p.setPreco(resultadoQ.getDouble("preco"));
            p.setEstoque(resultadoQ.getInt("estoque"));
            p.setCodCategoria(resultadoQ.getInt("codcategoria"));

            produtos.add(p);
        }

        return produtos;
    }

    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM produto WHERE codproduto = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void editar(Produto p) throws SQLException {
        String sql = ""
                + "UPDATE produto SET "
                + "nomeproduto = '" + p.getNomeProduto() + "',"
                + "preco = '" + p.getPreco() + "',"
                + "estoque = '" + p.getEstoque() + "',"
                + "codcategoria = '" + p.getCodCategoria() + "'"
                + "WHERE codproduto = " + p.getCodProduto();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public Produto recuperarUm(int id) throws SQLException {

        String sql = ""
                + "SELECT * FROM produto WHERE codproduto = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            Produto p = new Produto();

            p.setCodProduto(resultadoQ.getInt("codproduto"));
            p.setNomeProduto(resultadoQ.getString("nomeproduto"));
            p.setPreco(Double.parseDouble(resultadoQ.getString("preco")));
            p.setEstoque(Integer.parseInt(resultadoQ.getString("estoque")));
            p.setCodCategoria(Integer.parseInt(resultadoQ.getString("codcategoria")));

            return p;
        }

        return null;
    }
    
    public void editarEstoque(Produto p, int quantidadeNova) throws SQLException {
        String sql = ""
                + "UPDATE produto SET "
                + "estoque = " + quantidadeNova + " "
                + "WHERE codproduto = " + p.getCodProduto();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }
}
