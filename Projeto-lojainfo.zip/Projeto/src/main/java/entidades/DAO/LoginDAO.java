/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Login;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jeanl
 */
public class LoginDAO {

    private ResultSet resultadoQ = null; // interface que representa o resultado de uma consulta SQL executada em um banco de dados

    public boolean login(Login l) throws SQLException {

        String sql = ""
                + "SELECT codusuario FROM usuario "
                + "WHERE usuario = '" + l.getUsuario() + "' "
                + "AND senha = md5('" + l.getSenha() + "')";

        resultadoQ = ConexaoBD.executeQuery(sql);

        return resultadoQ.next();
    }

    public void salvar(Login l) throws SQLException {
        String sql = ""
                + "INSERT INTO usuario (usuario, senha) VALUES ("
                + "'" + l.getUsuario() + "',"
                + " md5('" + l.getSenha() + "'))";

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public ArrayList<Login> recuperarTodos() throws SQLException {
        ArrayList<Login> usuarios = new ArrayList();

        String sql = ""
                + "SELECT * FROM usuario";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Login l = new Login();

            l.setCodUsuario(resultadoQ.getInt("codusuario"));
            l.setUsuario(resultadoQ.getString("usuario"));
            l.setSenha(resultadoQ.getString("senha"));

            usuarios.add(l);
        }

        return usuarios;
    }

    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM usuario WHERE codusuario = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void editar(Login l) throws SQLException {
        String sql = ""
                + "UPDATE usuario SET "
                + "usuario = '" + l.getUsuario() + "',"
                + "senha = md5('" + l.getSenha() + "')"
                + "WHERE codusuario = " + l.getCodUsuario();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public Login recuperarUm(int id) throws SQLException {

        String sql = ""
                + "SELECT * FROM usuario WHERE codusuario = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            Login l = new Login();

            l.setCodUsuario(resultadoQ.getInt("codusuario"));
            l.setUsuario(resultadoQ.getString("usuario"));
            l.setSenha(resultadoQ.getString("senha"));

            return l;
        }

        return null;
    }
}
