/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.ConexaoBD;
import entidades.Produto;
import entidades.Venda;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class VendaDAO {

    private ResultSet resultadoQ = null; // interface que representa o resultado de uma consulta SQL executada em um banco de dados

    public Venda salvarNoProdutoVenda(Venda v) throws SQLException {

        String sql = ""
                + "INSERT INTO venda (codcliente, datavenda, totalvalor, tipopagamento, statusvenda) VALUES ("
                + "" + v.getCodCliente() + ","
                + "'" + v.getDataVenda() + "',"
                + "" + v.getTotalValor() + ","
                + "'" + v.getTipoPagamento() + "',"
                + "'" + v.getStatusVenda() + "'"
                + ")";

        System.out.println("sql: " + sql);

        int id = ConexaoBD.executeUpdateReturnId(sql);
        return recuperarUm(id);
    }

    public boolean salvar(Venda v) throws SQLException {

        String sql = ""
                + "INSERT INTO venda (codcliente, datavenda, totalvalor, tipopagamento, statusvenda) VALUES ("
                + "" + v.getCodCliente() + ","
                + "'" + v.getDataVenda() + "',"
                + "" + v.getTotalValor() + ","
                + "'" + v.getTipoPagamento() + "',"
                + "'" + v.getStatusVenda() + "'"
                + ")";

        System.out.println("sql: " + sql);

        int id = ConexaoBD.executeUpdateReturnId(sql);
        return true;
    }

    public ArrayList<Venda> recuperarTodos() throws SQLException {
        ArrayList<Venda> vendas = new ArrayList();

        String sql = ""
                + "SELECT * FROM venda ";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Venda v = new Venda();

            v.setCodVenda(resultadoQ.getInt("codvenda"));
            v.setCodCliente(resultadoQ.getInt("codcliente"));
            v.setDataVenda(resultadoQ.getString("datavenda"));
            v.setTotalValor(resultadoQ.getDouble("totalvalor"));
            v.setTipoPagamento(resultadoQ.getString("tipopagamento"));
            v.setStatusVenda(resultadoQ.getString("statusvenda"));

            vendas.add(v);
        }

        return vendas;
    }

    public ArrayList<Venda> recuperarTodos(String criterio) throws SQLException {
        ArrayList<Venda> vendas = new ArrayList();

        String sql = ""
                + "SELECT *\n"
                + "FROM cliente c, venda v\n"
                + "WHERE c.codcliente = v.codcliente\n"
                + "AND nomecliente ILIKE '%" + criterio + "%'";

        resultadoQ = ConexaoBD.executeQuery(sql);

        while (resultadoQ.next()) {
            Venda v = new Venda();

            v.setCodVenda(resultadoQ.getInt("codvenda"));
            v.setCodCliente(resultadoQ.getInt("codcliente"));
            v.setDataVenda(resultadoQ.getString("datavenda"));
            v.setTotalValor(resultadoQ.getDouble("totalvalor"));
            v.setTipoPagamento(resultadoQ.getString("tipopagamento"));
            v.setStatusVenda(resultadoQ.getString("statusvenda"));

            vendas.add(v);
        }

        return vendas;
    }

    public void excluir(int id) throws SQLException {
        String sql = ""
                + "DELETE FROM venda WHERE codvenda = " + id;

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public void editar(Venda v) throws SQLException {
        String sql = ""
                + "UPDATE venda SET "
                + "datavenda = '" + v.getDataVenda() + "',"
                + "totalvalor = '" + v.getTotalValor() + "',"
                + "tipopagamento = '" + v.getTipoPagamento() + "',"
                + "statusvenda = '" + v.getStatusVenda() + "'"
                + "WHERE codvenda = " + v.getCodVenda();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }

    public Venda recuperarUm(int id) throws SQLException {

        String sql = ""
                + "SELECT * FROM venda WHERE codvenda = " + id;

        resultadoQ = ConexaoBD.executeQuery(sql);

        if (resultadoQ.next()) {
            Venda v = new Venda();

            v.setCodVenda(resultadoQ.getInt("codvenda"));
            v.setCodCliente((resultadoQ.getInt("codcliente")));
            v.setDataVenda((resultadoQ.getString("datavenda")));
            v.setTotalValor(resultadoQ.getDouble("totalvalor"));
            v.setTipoPagamento(resultadoQ.getString("tipopagamento"));
            v.setStatusVenda(resultadoQ.getString("statusvenda"));

            return v;
        }

        return null;
    }

    public void editarValor(Venda v, double valor) throws SQLException {
        String sql = ""
                + "UPDATE venda SET "
                + "totalvalor = " + valor + " "
                + "WHERE codvenda = " + v.getCodVenda();

        System.out.println("sql: " + sql);

        ConexaoBD.executeUpdate(sql);
    }
}
