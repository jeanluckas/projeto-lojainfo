/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades.DAO;

import apoio.FileManager;
import entidades.Venda;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class VendaDAO {
    private final String caminhoArquivo = "vendas.txt";

    public void salvar(Venda v) {
        FileManager.adicionarLinhaNoArquivo(v.toString(), caminhoArquivo);
    }

    public ArrayList<Venda> recuperarTodos() {
        ArrayList<String> linhas = FileManager.lerLinhasDoArquivo(caminhoArquivo);
        ArrayList<Venda> vendas = new ArrayList();

        for (String linha : linhas) {
            String[] partes = linha.split(";");
            String cliente = partes[0];
            String produto = partes[1];
            String quantidade = partes[2];
            String dtVenda = partes[3];
            String formaPagamento = partes[4];

            Venda v = new Venda();
            v.setCliente(cliente);
            v.setProduto(produto);
            v.setQuantidade(Integer.parseInt(quantidade));
            v.setDtVenda(dtVenda);
            v.setFormaPagamento(formaPagamento);

            vendas.add(v);
        }

        return vendas;
    }
}
