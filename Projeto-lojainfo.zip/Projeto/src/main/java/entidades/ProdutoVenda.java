/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author jeanl
 */
public class ProdutoVenda {
    private int codProdutoVenda;
    private int codVenda;
    private int codProduto;
    private int quantidade;

    public int getCodProdutoVenda() {
        return codProdutoVenda;
    }

    public void setCodProdutoVenda(int codProdutoVenda) {
        this.codProdutoVenda = codProdutoVenda;
    }

    public int getCodVenda() {
        return codVenda;
    }

    public void setCodVenda(int codVenda) {
        this.codVenda = codVenda;
    }

    public int getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(int codProduto) {
        this.codProduto = codProduto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    
}
