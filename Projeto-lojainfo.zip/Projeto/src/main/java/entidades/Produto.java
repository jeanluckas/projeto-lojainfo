/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author jeanl
 */
public class Produto {

    private int codProduto;
    private String nomeProduto;
    private double preco;
    private int estoque;
    private int codCategoria;

    public int getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(int codProduto) {
        this.codProduto = codProduto;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public int getCodCategoria() {
        return codCategoria;
    }

    public void setCodCategoria(int idCategoria) {
        this.codCategoria = idCategoria;
    }

    @Override
    public String toString() {
        String retorno = nomeProduto + ";" + preco + ";" + codCategoria + ";" + estoque;
        return retorno;
    }
}
