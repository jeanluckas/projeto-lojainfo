/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author jeanl
 */
public class Produto {

    private int codProduto;
    private String nome;
    private double preco = 0;
    private int estoque = 0;
    private int idCategoria = 0;

    public int getIdProduto() {
        return codProduto;
    }

    public void setIdProduto(int idProduto) {
        this.codProduto = idProduto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }
    
    @Override
    public String toString() {
        String retorno = nome + ";" + preco + ";" + idCategoria + ";" + estoque;
        return retorno;
    }
}
