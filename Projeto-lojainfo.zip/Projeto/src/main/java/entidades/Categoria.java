/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author jean.roth
 */
public class Categoria {
    private int codCategoria;
    private String nome;
    private String desc;

    public int getIdCategoria() {
        return codCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.codCategoria = idCategoria;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
    
    @Override
    public String toString() {
        String retorno = nome + ";" + desc;
        return retorno;
    }
}
