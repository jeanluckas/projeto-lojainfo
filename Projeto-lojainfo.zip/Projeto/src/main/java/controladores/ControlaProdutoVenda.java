/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;
import entidades.DAO.ProdutoVendaDAO;
import entidades.ProdutoVenda;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jeanl
 */
public class ControlaProdutoVenda {
    private ProdutoVendaDAO pvDAO = new ProdutoVendaDAO();

    public boolean salvar(ProdutoVenda cpv) {
        try {
            pvDAO.salvar(cpv);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar produtos na venda: " + ex.getMessage());
            return false;
        }
    }

    public ArrayList<ProdutoVenda> recuperarTodos() {
        try {
            return pvDAO.recuperarTodos();
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar produtos na venda: " + ex.getMessage());
            return null;
        }
    }
    
    public boolean excluir(int id){
        try {
            pvDAO.excluir(id);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir produtos na venda: " + ex.getMessage());
            return false;
        }
    }
}
