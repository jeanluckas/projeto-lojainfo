/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.Cliente;
import entidades.DAO.ClienteDAO;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaCliente {

    private ClienteDAO cDAO = new ClienteDAO();

    public void salvar(Cliente c) {
        cDAO.salvar(c);
    }

    public ArrayList<Cliente> recuperaTodos() {
        return cDAO.recuperarTodos();
    }
}
