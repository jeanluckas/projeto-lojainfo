/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.DAO.ProdutoDAO;
import entidades.Produto;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaProduto {
    private ProdutoDAO pDAO = new ProdutoDAO();
    
    public void salvar(Produto p) {
        pDAO.salvar(p);
    }
    
    public ArrayList<Produto> recuperaTodos() {
        return pDAO.recuperarTodos();
    }
    
}
