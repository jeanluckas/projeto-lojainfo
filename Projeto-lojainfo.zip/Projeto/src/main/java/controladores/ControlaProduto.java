/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.DAO.ProdutoDAO;
import entidades.Produto;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaProduto {

    private ProdutoDAO pDAO = new ProdutoDAO();

    public boolean salvar(Produto cp) {
        try {
            pDAO.salvar(cp);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar produto: " + ex.getMessage());
            return false;
        }
    }

    public ArrayList<Produto> recuperarTodos() {
        try {
            return pDAO.recuperarTodos();
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar produto: " + ex.getMessage());
            return null;
        }
    }

    public ArrayList<Produto> recuperarTodos(String criterio) {
        ArrayList<Produto> vetorProdutos = null;
        try {
            vetorProdutos = pDAO.recuperarTodos(criterio);
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar clientes: " + ex.getMessage());
        }
        return vetorProdutos;
    }

    public boolean excluir(int id) {
        try {
            pDAO.excluir(id);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir produto: " + ex.getMessage());
            return false;
        }
    }

    public Produto recuperarUm(int id) {
        try {
            return pDAO.recuperarUm(id);
        } catch (SQLException ex) {
            System.out.println("Erro ao recuperar produto: " + ex.getMessage());
            return null;
        }
    }

    public boolean editar(Produto p) {
        try {
            pDAO.editar(p);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao editar produto: " + ex.getMessage());
            return false;
        }
    }

    public boolean editarEstoque(Produto p, int estoque) {
        try {
            pDAO.editarEstoque(p, estoque);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao editar produto: " + ex.getMessage());
            return false;
        }
    }

    public static boolean validarEstoque(int id, int estoque) {
        ControlaProduto cp = new ControlaProduto();
        Produto p = cp.recuperarUm(id);

        if (p.getEstoque() - estoque >= 0) {
            return true;
        }
        return false;
    }
}
