/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.DAO.UsuarioDAO;
import entidades.Usuario;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jeanl
 */
public class ControlaUsuario {

    private UsuarioDAO lDAO = new UsuarioDAO();

    public boolean login(Usuario l) {
        try {
            return lDAO.login(l);
        } catch (SQLException ex) {
            System.out.println("Erro ao logar: " + ex.getMessage());
            return false;
        }
    }

    public boolean salvar(Usuario l) {
        try {
            lDAO.salvar(l);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar usuário: " + ex.getMessage());
            return false;
        }
    }

    public ArrayList<Usuario> recuperarTodos() {
        try {
            return lDAO.recuperarTodos();
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar usuario: " + ex.getMessage());
            return null;
        }
    }

    public boolean excluir(int id) {
        try {
            lDAO.excluir(id);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir usuario: " + ex.getMessage());
            return false;
        }
    }

    public Usuario recuperarUm(int id) {
        try {
            return lDAO.recuperarUm(id);
        } catch (SQLException ex) {
            System.out.println("Erro ao recuperar usuario: " + ex.getMessage());
            return null;
        }
    }

    public boolean editar(Usuario l) {
        try {
            lDAO.editar(l);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao editar usuario: " + ex.getMessage());
            return false;
        }
    }

}
