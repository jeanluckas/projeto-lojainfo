/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.DAO.VendaDAO;
import entidades.Venda;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaVenda {

    private VendaDAO vDAO = new VendaDAO();

    public boolean salvar(Venda cv) {
        try {
            vDAO.salvar(cv);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar venda: " + ex.getMessage());
            return false;
        }
    }

    public ArrayList<Venda> recuperarTodos() {
        try {
            return vDAO.recuperarTodos();
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar venda: " + ex.getMessage());
            return null;
        }
    }

    public boolean excluir(int id) {
        try {
            vDAO.excluir(id);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir venda: " + ex.getMessage());
            return false;
        }
    }

    public Venda recuperarUm(int id) {
        try {
            return vDAO.recuperarUm(id);
        } catch (SQLException ex) {
            System.out.println("Erro ao recuperar produto: " + ex.getMessage());
            return null;
        }
    }

    public boolean editar(Venda v) {
        try {
            vDAO.editar(v);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao editar produto: " + ex.getMessage());
            return false;
        }
    }
}
