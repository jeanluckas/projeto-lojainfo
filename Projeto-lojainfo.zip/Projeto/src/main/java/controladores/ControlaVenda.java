/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.DAO.VendaDAO;
import entidades.Venda;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaVenda {

    private VendaDAO vDAO = new VendaDAO();

    public void salvar(Venda v) {
        vDAO.salvar(v);
    }

    public ArrayList<Venda> recuperaTodos() {
        return vDAO.recuperarTodos();
    }
}
