/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.Cliente;
import entidades.DAO.VendaDAO;
import entidades.Venda;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaVenda {

    private VendaDAO vDAO = new VendaDAO();

    public boolean salvar(Venda v) {
        try {
            vDAO.salvar(v);
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar pedido: " + ex.getMessage());
        }
        return true;
    }
    
    public Venda salvarNoProdutoVenda(Venda v) {
        Venda vSalvo = null;
        try {
            vSalvo = vDAO.salvarNoProdutoVenda(v);
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar pedido: " + ex.getMessage());
        }
        return vSalvo;
    }
    

    public ArrayList<Venda> recuperarTodos() {
        try {
            return vDAO.recuperarTodos();
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar venda: " + ex.getMessage());
            return null;
        }
    }

    public boolean excluir(int id) {
        try {
            vDAO.excluir(id);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir venda: " + ex.getMessage());
            return false;
        }
    }

    public Venda recuperarUm(int id) {
        try {
            return vDAO.recuperarUm(id);
        } catch (SQLException ex) {
            System.out.println("Erro ao recuperar produto: " + ex.getMessage());
            return null;
        }
    }

    public boolean editar(Venda v) {
        try {
            vDAO.editar(v);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao editar produto: " + ex.getMessage());
            return false;
        }
    }

    public boolean editarValor(Venda v, double valor) {
        try {
            VendaDAO vDAO = new VendaDAO();
            vDAO.editarValor(v, valor);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao editar valor total da vennda: " + ex.getMessage());
            return false;
        }
    }
    
    public ArrayList<Venda> recuperarTodos(String criterio) {
        ArrayList<Venda> vetorVendas = null;
        try {
            vetorVendas = vDAO.recuperarTodos(criterio);
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar clientes: " + ex.getMessage());
        }
        return vetorVendas;
    }
}
