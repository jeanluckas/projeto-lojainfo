/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.Categoria;
import entidades.DAO.CategoriaDAO;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaCategoria {

    private CategoriaDAO ctgDAO = new CategoriaDAO();

    public boolean salvar(Categoria cc) {
        try {
            ctgDAO.salvar(cc);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar categoria: " + ex.getMessage());
            return false;
        }
    }

    public ArrayList<Categoria> recuperarTodos() {
        try {
            return ctgDAO.recuperarTodos();
        } catch (SQLException ex) {
            System.out.println("Erro ao salvar categoria: " + ex.getMessage());
            return null;
        }
    }

    public boolean excluir(int id) {
        try {
            ctgDAO.excluir(id);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir categoria: " + ex.getMessage());
            return false;
        }
    }

    public Categoria recuperarUm(int id) {
        try {
            return ctgDAO.recuperarUm(id);
        } catch (SQLException ex) {
            System.out.println("Erro ao recuperar categoria: " + ex.getMessage());
            return null;
        }
    }

    public boolean editar(Categoria ctg) {
        try {
            ctgDAO.editar(ctg);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao editar categoria: " + ex.getMessage());
            return false;
        }
    }
}
