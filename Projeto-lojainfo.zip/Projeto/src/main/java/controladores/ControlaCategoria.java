/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.Categoria;
import entidades.Cliente;
import entidades.DAO.CategoriaDAO;
import java.util.ArrayList;

/**
 *
 * @author jean.roth
 */
public class ControlaCategoria {

    private CategoriaDAO ctgDAO = new CategoriaDAO();

    public void salvar(Categoria ctg) {
        ctgDAO.salvar(ctg);
    }

    public ArrayList<Categoria> recuperaTodos() {
        return ctgDAO.recuperarTodos();
    }
}
