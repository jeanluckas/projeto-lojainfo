/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controladores;

import entidades.DAO.ProdutoVendaDAO;
import entidades.ProdutoVenda;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jeanl
 */
public class ControlaProdutoVenda {

    ProdutoVendaDAO produtoVendaDAO = new ProdutoVendaDAO();

    public boolean inserir(ProdutoVenda vp) {
        try {
            produtoVendaDAO.inserir(vp);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir item da venda: " + ex.getMessage());
            return false;
        }
    }

    public boolean remover(ProdutoVenda vp) {
        try {
            produtoVendaDAO.remover(vp);
            return true;
        } catch (SQLException ex) {
            System.out.println("Erro ao remover item da venda: " + ex.getMessage());
            return false;
        }
    }

    public ArrayList<ProdutoVenda> recuperarTodos(int pedidoId) {
        ArrayList<ProdutoVenda> vetorVendaProduto = null;
        try {
            vetorVendaProduto = produtoVendaDAO.recuperarTodos(pedidoId);
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar itens do pedido: " + ex.getMessage());
        }
        return vetorVendaProduto;
    }

    public ProdutoVenda recuperar(int id) {
        try {
            ProdutoVenda produto = produtoVendaDAO.recuperar(id);
            return produto;
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar itens do pedido: " + ex.getMessage());
            return null;
        }
    }
    
}
